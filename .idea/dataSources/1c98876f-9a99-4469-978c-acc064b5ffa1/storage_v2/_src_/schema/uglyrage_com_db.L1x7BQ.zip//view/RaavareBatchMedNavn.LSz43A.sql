create view RaavareBatchMedNavn as
select `uglyrage_com_db`.`Raavarebatch`.`raavareid`   AS `raavareid`,
       `uglyrage_com_db`.`Raavarebatch`.`rbid`        AS `rbid`,
       `uglyrage_com_db`.`Raavarebatch`.`maengde`     AS `maengde`,
       `uglyrage_com_db`.`Raavarebatch`.`leverandoer` AS `leverandoer`,
       `uglyrage_com_db`.`Raavare`.`raavarenavn`      AS `raavarenavn`
from (`uglyrage_com_db`.`Raavarebatch`
         join `uglyrage_com_db`.`Raavare`
              on ((`uglyrage_com_db`.`Raavarebatch`.`raavareid` = `uglyrage_com_db`.`Raavare`.`raavareid`)));

