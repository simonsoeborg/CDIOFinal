create view AfvejningReceptKomponent2 as
select `uglyrage_com_db`.`ProduktBatch`.`pbId`  AS `pbId`,
       `AfvejningReceptKomponent`.`raavareid`   AS `raavareid`,
       `AfvejningReceptKomponent`.`raavarenavn` AS `raavarenavn`,
       `AfvejningReceptKomponent`.`maengde`     AS `maengde`,
       `AfvejningReceptKomponent`.`tolerance`   AS `tolerance`
from (`uglyrage_com_db`.`AfvejningReceptKomponent`
         join `uglyrage_com_db`.`ProduktBatch`
              on ((`uglyrage_com_db`.`ProduktBatch`.`receptId` = `AfvejningReceptKomponent`.`receptId`)));

