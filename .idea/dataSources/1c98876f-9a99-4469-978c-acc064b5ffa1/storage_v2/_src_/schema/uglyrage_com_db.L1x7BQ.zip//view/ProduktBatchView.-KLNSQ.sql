create definer = uglyrage_com@`%` view ProduktBatchView as
(
select `uglyrage_com_db`.`ProduktBatch`.`pbid`                    AS `pbid`,
       `uglyrage_com_db`.`ProduktBatch`.`receptId`                AS `receptid`,
       `uglyrage_com_db`.`ProduktBatch`.`status`                  AS `status`,
       `uglyrage_com_db`.`ProduktBatch`.`userid`                  AS `userid`,
       `uglyrage_com_db`.`ProduktBatchKomponent`.`rbid`           AS `rbid`,
       `uglyrage_com_db`.`ProduktBatchKomponent`.`afvejetmaengde` AS `afvejetmaengde`,
       `uglyrage_com_db`.`ProduktBatchKomponent`.`tara`           AS `tara`
from (`uglyrage_com_db`.`ProduktBatchKomponent`
         left join `uglyrage_com_db`.`ProduktBatch`
                   on ((`uglyrage_com_db`.`ProduktBatchKomponent`.`pbid` = `uglyrage_com_db`.`ProduktBatch`.`pbid`))));

