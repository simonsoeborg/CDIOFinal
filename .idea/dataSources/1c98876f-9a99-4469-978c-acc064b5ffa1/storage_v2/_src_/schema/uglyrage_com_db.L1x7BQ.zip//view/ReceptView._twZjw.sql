create definer = uglyrage_com@`%` view ReceptView as
(
select `uglyrage_com_db`.`ReceptKomponent`.`receptid`  AS `receptid`,
       `uglyrage_com_db`.`Recept`.`receptnavn`         AS `receptnavn`,
       `uglyrage_com_db`.`ReceptKomponent`.`raavareid` AS `raavareid`,
       `uglyrage_com_db`.`Raavare`.`raavarenavn`       AS `raavarenavn`,
       `uglyrage_com_db`.`ReceptKomponent`.`maengde`   AS `maengde`,
       `uglyrage_com_db`.`ReceptKomponent`.`tolerance` AS `tolerance`
from ((`uglyrage_com_db`.`ReceptKomponent` left join `uglyrage_com_db`.`Recept` on ((
        `uglyrage_com_db`.`ReceptKomponent`.`receptid` = `uglyrage_com_db`.`Recept`.`receptid`)))
         left join `uglyrage_com_db`.`Raavare`
                   on ((`uglyrage_com_db`.`ReceptKomponent`.`raavareid` = `uglyrage_com_db`.`Raavare`.`raavareid`))));

