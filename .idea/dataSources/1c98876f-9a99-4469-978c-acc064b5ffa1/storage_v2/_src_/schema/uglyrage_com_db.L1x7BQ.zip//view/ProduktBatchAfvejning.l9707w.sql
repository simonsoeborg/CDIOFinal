create definer = uglyrage_com@`%` view ProduktBatchAfvejning as
select `R`.`receptNavn` AS `receptNavn`, `P`.`pbId` AS `pbId`
from (`uglyrage_com_db`.`Recept` `R`
         join `uglyrage_com_db`.`ProduktBatch` `P` on ((`R`.`receptId` = `P`.`receptId`)));

